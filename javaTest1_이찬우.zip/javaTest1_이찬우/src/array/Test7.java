package array;

public class Test7 {

	public static void main(String[] args) {
		
		int [] array = {1,2,3,4,5,6,7,8,9,10};
		double sum = 0;
		for(int i=1; i <= 10; i++) {
			if(i % 2 !=0 ) {
				System.out.println(i);
				sum += i;
			}	
		}
		System.out.println("힙계 : " + sum);
	}
}