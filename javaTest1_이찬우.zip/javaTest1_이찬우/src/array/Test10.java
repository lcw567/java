package array;

public class Test10 {

	public static void main(String[] args) {
        int [][] array = {
            {12, 41, 36, 56}, 
            {82, 10, 12, 61}, 
            {14, 16, 18, 78}, 
            {45, 26, 72, 23}
        };

        int[] copyAr = new int[array.length * array[0].length];
        int index = 0;

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                int value = array[i][j];
                if (value % 3 == 0 && !isInArray(copyAr, index, value)) {
                    copyAr[index++] = value;
                }
            }
        }

        System.out.print("copyAr : ");
        for (int i = 0; i < index; i++) {
            System.out.print(copyAr[i] + " ");
        }
    }


	public static boolean isInArray(int[] array, int length, int value) {
        for (int i = 0; i < length; i++) {
            if (array[i] == value) {
                return true;
        }
    }
    return false;
    }
}