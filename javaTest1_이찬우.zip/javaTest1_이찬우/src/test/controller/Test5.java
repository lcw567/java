package test.controller;

import java.util.Scanner;

public class Test5 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int num1, num2;
		System.out.print("정수 입력 : ");
		num1 = sc.nextInt();
		
		System.out.print("정수 입력 : ");
		num2 = sc.nextInt();
		
		int product = num1 * num2;
		
		if(product < 10) {
			System.out.println("한자리 수 입니다.");
		} else {
			System.out.println("두자리 수 입니다.");
		}
		

	}

}
