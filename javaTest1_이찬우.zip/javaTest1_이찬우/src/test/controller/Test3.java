package test.controller;

public class Test3 {

	public static void main(String[] args) {
        
		int sum = 0;
        int count = 1;

        while (count <= 100) {
            sum += count;
            count++;
        }

        double average = (double) sum / 100;

        System.out.println("합계 : " + sum);
        System.out.printf("평균 : %.1f%n", average);
    }
}
