package test.controller;

import java.util.Scanner;

public class Test4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num1, num2;
		System.out.print("정수 입력 : ");
		num1 = sc.nextInt();
		
		System.out.print("정수 입력 : ");
		num2 = sc.nextInt();
		
		if ((num1 < 1 || num1 > 9) || (num2 < 1 || num2 > 9)) {
            System.out.println("입력 값은 1부터 9까지의 정수여야 합니다.");
            return;            
		}
		
		int sum = num1 + num2;
        int difference = num1 - num2;
        int product = num1 * num2;
        int quotient = (num2 <= 0) ? 0 : num1 / num2;
        
        System.out.println("합 : " + sum);
        System.out.println("차 : " + difference);
        System.out.println("곱 : " + product);
        System.out.println("나누기 : " + quotient);
                
	}

}
